"""Audit logging service — tracks every schedule change."""

import json
from datetime import date
from typing import Optional
import aiosqlite


async def log_action(
    db: aiosqlite.Connection,
    action: str,
    schedule_date: Optional[date] = None,
    board_type: Optional[str] = None,
    details: Optional[dict] = None,
):
    """Record an audit log entry.

    Actions: 'schedule', 'edit', 'override', 'delete', 'swap', 'fallback_triggered'
    """
    details_json = json.dumps(details) if details else None
    await db.execute(
        """INSERT INTO tv_audit_log (action, schedule_date, board_type, details)
           VALUES (?, ?, ?, ?)""",
        (action, str(schedule_date) if schedule_date else None, board_type, details_json),
    )
    await db.commit()


async def get_audit_log(
    db: aiosqlite.Connection,
    page: int = 1,
    page_size: int = 50,
    action_filter: Optional[str] = None,
    board_filter: Optional[str] = None,
) -> tuple[list[dict], int]:
    """Retrieve paginated audit log entries.

    Returns (entries, total_count).
    """
    where_clauses = []
    params = []

    if action_filter:
        where_clauses.append("action = ?")
        params.append(action_filter)
    if board_filter:
        where_clauses.append("board_type = ?")
        params.append(board_filter)

    where_sql = f" WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

    # Get total count
    cursor = await db.execute(
        f"SELECT COUNT(*) FROM tv_audit_log{where_sql}", params
    )
    row = await cursor.fetchone()
    total = row[0]

    # Get page
    offset = (page - 1) * page_size
    cursor = await db.execute(
        f"""SELECT id, action, schedule_date, board_type, details, timestamp
            FROM tv_audit_log{where_sql}
            ORDER BY timestamp DESC
            LIMIT ? OFFSET ?""",
        params + [page_size, offset],
    )
    rows = await cursor.fetchall()
    entries = [dict(row) for row in rows]

    return entries, total
